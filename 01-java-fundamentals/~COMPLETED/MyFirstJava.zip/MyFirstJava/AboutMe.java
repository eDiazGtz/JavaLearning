public class AboutMe{
    public static void main(String [] args) {
        String myName = "Edgar";
        int myAge = 30;
        String myTown = "San Diego, CA";
        System.out.println("My name is " + myName);
        System.out.println("I am " + myAge + " years old");
        System.out.println("My hometown is " + myTown);
    }
}