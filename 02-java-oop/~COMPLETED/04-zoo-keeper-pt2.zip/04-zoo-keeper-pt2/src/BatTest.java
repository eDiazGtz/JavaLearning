public class BatTest {
    public static void main(String[] args) {
        Bat countDracula = new Bat();
        countDracula.displayEnergy();
        countDracula.eatHumans();
        countDracula.displayEnergy();
        countDracula.attackTown();
        countDracula.displayEnergy();
        countDracula.attackTown();
        countDracula.displayEnergy();
        countDracula.attackTown();
        countDracula.displayEnergy();
        countDracula.eatHumans();
        countDracula.eatHumans();
        countDracula.displayEnergy();
        countDracula.fly();
        countDracula.fly();
        countDracula.displayEnergy();
    }
}