
public class GorillaTest {
	public static void main(String[] args) {
		Gorilla jojo = new Gorilla();
		jojo.displayEnergy();
		jojo.throwSomething();
		jojo.throwSomething();
		jojo.throwSomething();
		jojo.displayEnergy();
		jojo.eatBananas();
		jojo.eatBananas();
		jojo.displayEnergy();
		jojo.climb();
		jojo.displayEnergy();
	}
}
